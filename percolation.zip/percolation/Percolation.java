import edu.princeton.cs.algs4.WeightedQuickUnionUF;

public class Percolation {
    private final int n;
    private final boolean[] sitesStates;
    private final WeightedQuickUnionUF wqu;
    private int numOfOpenSites = 0;

    // creates n-by-n grid, with all sites initially blocked
    public Percolation(int n) {
        if (n < 1) throw new IllegalArgumentException("n can't be less than 1");
        this.n = n;
        final int totalSize = n * n;
        wqu = new WeightedQuickUnionUF(totalSize);
        sitesStates = new boolean[totalSize];
    }

    // opens the site (row, col) if it is not open already
    public void open(int row, int col) {
        validates(row, col);
        int i = getIndex(row, col);
        sitesStates[i] = true;
        numOfOpenSites++;
        // up
        union(i, i - n);
        // down
        union(i, i + n);
        // left
        union(i, i - 1);
        // right
        union(i, i + 1);
    }

    // is the site (row, col) open?
    public boolean isOpen(int row, int col) {
        validates(row, col);
        int i = getIndex(row, col);
        return sitesStates[i];
    }

    // is the site (row, col) full? is this connected to another site that reaches the other side?
    public boolean isFull(int row, int col) {
        validates(row, col);
        if (!isOpen(row, col)) return false;
        int idx = getIndex(row, col);
        for (int i = 0; i < n; i++) {
            if (isOpenByIndex(i) && isConnected(idx, i)) {
                return true;
            }
        }

        return false;
    }

    // returns the number of open sites
    public int numberOfOpenSites() {
        return numOfOpenSites;
    }

    // does the system percolate?
    public boolean percolates() {
        for (int i = 0; i < n; i++) {
            if (!isOpenByIndex(i)) continue;
            for (int j = sitesStates.length - n; j < sitesStates.length; j++) {
                if (isOpenByIndex(j) && isConnected(i, j)) return true;
            }
        }
        return false;
    }

    private int getIndex(int row, int col) {
        return (row - 1) * n + (col - 1);
    }

    private boolean isOpenByIndex(int i) {
        return sitesStates[i];
    }

    private void union(int first, int second) {
        if (second < 0 || second >= sitesStates.length || !isOpenByIndex(second)) return;
        int firstRoot = wqu.find(first);
        int secondRoot = wqu.find(second);
        if (firstRoot == secondRoot) return;
        wqu.union(first, second);
    }

    private boolean isConnected(int first, int second) {
        return wqu.find(first) == wqu.find(second);
    }

    private void validates(int row, int col) {
        if (row < 1 || row > n || col < 1 || col > n) throw new IllegalArgumentException();
    }
}
